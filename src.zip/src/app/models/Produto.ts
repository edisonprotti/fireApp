export class Produto {
  id: string;
  nome: string;
  descricao: string;
  estoque: number;
  valor: number;
}

